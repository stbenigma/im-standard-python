CREATE VIEW langattr as
        	        select lgtx_text,lang_id,lang_iso_code2,lgtx_mode_id,lgtx_attrname
        	          from lang_texts 
        	          join languages on lang_id = lgtx_lang_id;


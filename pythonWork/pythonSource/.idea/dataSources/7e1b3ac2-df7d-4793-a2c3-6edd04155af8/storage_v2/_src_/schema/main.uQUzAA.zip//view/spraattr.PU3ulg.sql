CREATE VIEW spraattr as
	        select sptx_text,spra_id,spra_iso_code2,sptx_mode_id,sptx_attrname
	          from sprachtexte 
	          join sprachen on spra_id = sptx_spra_id;


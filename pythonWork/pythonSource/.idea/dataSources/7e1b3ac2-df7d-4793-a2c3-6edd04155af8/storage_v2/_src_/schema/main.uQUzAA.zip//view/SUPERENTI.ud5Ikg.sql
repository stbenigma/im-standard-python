CREATE VIEW SUPERENTI AS 
    select ae.enti_id super_enti_id,ae.enti_name super_enti_name
               ,e1.enti_id sub_enti_id,e1.enti_name sub_enti_name
      from arcs
      join entitaeten as ae on ae.enti_id = arcs_enti_id 
      join (select bezi_arcs_id
                   ,count(*) alleanz
           , SUM(case bezi_pflicht_assoc_von_zu when 'TRUE' then 1 else 0 end) nnvonanz
           , SUM(case bezi_pflicht_assoc_zu_von when 'TRUE' then 1 else 0 end) nnzuanz
            from   (select case when bezi_von_arcs_id is null then bezi_zu_arcs_id else bezi_von_arcs_id end bezi_arcs_id
                        , bezi_pflicht_assoc_von_zu
                        , bezi_pflicht_assoc_zu_von
                   from beziehungen
                   where bezi_type in ('ISA', '1:1')
                )
            group by bezi_arcs_id) as st
            on st.bezi_arcs_id = arcs_id AND  alleanz = nnvonanz and alleanz = nnzuanz
      join beziehungen b1 on b1.bezi_von_arcs_id = arcs_id or b1.bezi_zu_arcs_id = arcs_id
      join entitaeten e1 on e1.enti_id = b1.bezi_enti_id_von  
    order by ae.enti_name;


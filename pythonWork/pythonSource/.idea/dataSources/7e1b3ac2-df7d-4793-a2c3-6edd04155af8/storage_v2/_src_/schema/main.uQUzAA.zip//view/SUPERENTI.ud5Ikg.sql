CREATE VIEW SUPERENTI AS
    select superentity.rela_type,superentity.enti_id as superenti_id, superentity.enti_name as super_enti_name
        ,subentity.enti_id as subenti_id, subentity.enti_name as sub_enti_name
    from (select enti_id,enti_name,rela_type,rela_subenti_id
          from ENTITIES
            join ARCS on ARCS_ENTI_ID = enti_id
           join (select rela_id
                       , rela_type
                       , case
                             when RELA_ARCS_ID_FROM is NULL then RELA_ARCS_ID_TO
                             else RELA_ARCS_ID_FROM end  as rela_arcs_id
                       , case
                             when RELA_ARCS_ID_FROM is NULL then RELA_ENTI_ID_TO
                              else RELA_ENTI_ID_FROM end as rela_subenti_id
                     from relations
                     where RELA_TYPE =  'ISAS'
          ) relas on RELA_ARCS_ID = arcs_id
        union all
        select rela_superenti_id, enti_name, rela_type,rela_subenti_id
        from (select rela_type
               , case
                     when RELA_MANDATORY_TO_FROM = 'TRUE' then RELA_ENTI_ID_FROM
                     else RELA_ENTI_ID_TO end as rela_superenti_id
               , case
                     when RELA_MANDATORY_FROM_TO = 'TRUE' then RELA_ENTI_ID_FROM
                     else RELA_ENTI_ID_TO end as rela_subenti_id
          from relations
          where rela_type = 'ISAR'
         )
        join entities on enti_id = rela_superenti_id
        ) superentity
    join ENTITIES subentity on subentity.ENTI_ID = rela_subenti_id;


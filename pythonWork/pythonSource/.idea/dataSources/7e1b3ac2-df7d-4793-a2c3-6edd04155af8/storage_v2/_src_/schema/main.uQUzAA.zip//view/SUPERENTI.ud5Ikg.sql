CREATE VIEW SUPERENTI AS 
            select superentity.enti_id as superenti_id, superentity.enti_name as super_enti_name
            ,subentity.enti_id as subenti_id, subentity.enti_name as sub_enti_name
        from ENTITIES superentity
         join ARCS on ARCS_ENTI_ID = superentity.enti_id
         join (select rela_id
                    ,case when RELA_ARCS_ID_FROM is NULL then RELA_ARCS_ID_TO else RELA_ARCS_ID_FROM end as rela_arcs_id
                    ,case when RELA_ARCS_ID_FROM is NULL then  RELA_ENTI_ID_TO else RELA_ENTI_ID_FROM end as rela_enti_id
                    from relations
                    where RELA_TYPE = 'ISAS') relas on RELA_ARCS_ID= arcs_id
        join ENTITIES subentity on subentity.ENTI_ID = rela_enti_id;

